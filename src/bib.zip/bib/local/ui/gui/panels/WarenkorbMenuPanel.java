package bib.local.ui.gui.panels;

import bib.local.domain.EShop;
import bib.local.domain.exceptions.*;
import bib.local.entities.Artikel;
import bib.local.entities.Kunde;
import bib.local.entities.Warenkorb;
import bib.local.entities.WarenkorbEintrag;
import bib.local.ui.gui.models.ArtikelInWarenkorbTableModel;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

/**
 * Panel zum Anzeigen des Warenkorbs eines Kunden.
 */
public class WarenkorbMenuPanel extends JPanel {

    private EShop shop;
    private Kunde eingeloggterKunde;
    private ArtikelInWarenkorbTablePanel artikelInWarenkorbTablePanel;
    private ArtikelInWarenkorbTableModel artikelInWarenkorbTableModel;
    private JButton zurueckButton;
    private JButton rechnungButton;
    private JButton entfehrnenButton;

    /**
     * Konstruktor für WarenkorbMenuPanel.
     *
     * @param cardLayout       der CardLayout-Manager
     * @param mainPanel        das Hauptpanel, das alle Kartenpanels enthält
     * @param shop             die EShop-Instanz
     * @param eingeloggterKunde der eingeloggte Kunde
     */
    public WarenkorbMenuPanel(CardLayout cardLayout, JPanel mainPanel, EShop shop, Kunde eingeloggterKunde) {
        this.shop = shop;
        this.eingeloggterKunde = eingeloggterKunde;
        setupUI();
        setupEvents(cardLayout, mainPanel);
    }

    /**
     * Initialisiert die Benutzeroberfläche.
     */
    private void setupUI() {
        setLayout(new BorderLayout());

        try {
            List<WarenkorbEintrag> artikelListe = shop.getWarenkorbVW().WarenkorbAnzeigen(eingeloggterKunde);
            artikelInWarenkorbTablePanel = new ArtikelInWarenkorbTablePanel(artikelListe, shop, eingeloggterKunde);
            add(new JScrollPane(artikelInWarenkorbTablePanel), BorderLayout.CENTER);
        } catch (WarenkorbLeerException e) {
            JOptionPane.showMessageDialog(this, "Der Warenkorb ist leer.", "Fehler", JOptionPane.ERROR_MESSAGE);
        }

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        zurueckButton = new JButton("Zurück");
        rechnungButton = new JButton("Rechnung anzeigen");
        entfehrnenButton = new JButton("Artikel entfehrnen");

        buttonPanel.add(zurueckButton);
        buttonPanel.add(rechnungButton);
        buttonPanel.add(entfehrnenButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Setzt die Ereignishandler für die Komponenten.
     *
     * @param cardLayout der CardLayout-Manager
     * @param mainPanel  das Hauptpanel, das alle Kartenpanels enthält
     */
    private void setupEvents(CardLayout cardLayout, JPanel mainPanel) {
        zurueckButton.addActionListener(e -> cardLayout.show(mainPanel, "kundeMenu"));

        rechnungButton.addActionListener(e -> {
            JPanel rechnungPanel = new RechnungPanel(shop, eingeloggterKunde, cardLayout, mainPanel);
            mainPanel.add(rechnungPanel, "rechnung");
            cardLayout.show(mainPanel, "rechnung");
        });

        entfehrnenButton.addActionListener(e -> {
            try {
                entferneArtikelAusWarenkorb();
            } catch (IOException | WarenkorbLeerException ex) {
                JOptionPane.showMessageDialog(WarenkorbMenuPanel.this, "Fehler: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    @Override
    public void updateListe(Kunde eingeloggterKunde) {
        try {
            artikelInWarenkorbTablePanel.updateArtikelliste(shop.getWarenkorbVW().WarenkorbAnzeigen(eingeloggterKunde));
        } catch (WarenkorbLeerException e) {
            throw new RuntimeException(e);
        }
    }

    private void entferneArtikelAusWarenkorb() throws IOException, WarenkorbLeerException {
        int selectedRow = artikelInWarenkorbTablePanel.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Bitte wählen Sie einen Artikel aus.", "Fehler", JOptionPane.ERROR_MESSAGE);
            return;
        }

        WarenkorbEintrag eintrag = artikelInWarenkorbTablePanel.getModel().getArtikelAt(selectedRow);
        int eintragNr = eintrag.getArtikel().getNummer();

        try {
            shop.entferneArtikelAusWarenkorb(eingeloggterKunde, eintragNr);
            JOptionPane.showMessageDialog(this, "Artikel wurde aus dem Warenkorb entfernt.");

            // Entfernen des Artikels aus der Tabelle
            updateListe(eingeloggterKunde);

            // Aktualisieren der Tabelle nach der Entfernung
            /*List<WarenkorbEintrag> aktualisierteArtikelListe = shop.getWarenkorbVW().WarenkorbAnzeigen(eingeloggterKunde);
            artikelInWarenkorbTablePanel.getModel().setArtikelList(aktualisierteArtikelListe);
            artikelInWarenkorbTablePanel.getModel().fireTableDataChanged();*/

        } catch (BestandPasstNichtMitPackungsGroesseException | NichtGenuegendBestandException |
                 ArtikelNichtGefundenException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

}